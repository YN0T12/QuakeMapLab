I've added the 4 wads that I'm pretty sure you can't find on any wesbites.

The two that don't have readmes are by Killjoy (who modified the orginal Ogro tex) and Daz (?) (clockwork.wad)